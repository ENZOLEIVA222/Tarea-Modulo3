package bibliotecavirtual;

import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        Libro biblioteca = new Libro();

        System.out.println("1. AGREGAR LIBROS");
        biblioteca.agregarLibro("Don quijote de la mancha", "Miguel de Cervantes",1615, "Novela de Caballeria");
        biblioteca.agregarLibro("Cien años de soledad", "Gabriel García Márquez", 1967, "Realismo mágico");
        biblioteca.agregarLibro("Orgulloso y prejuicio", "Jane Austen", 1813, "Novela Romantica");
        biblioteca.mostrarLibrosDisponibles();

        System.out.println("\n");
        System.out.println("2. BUSCAR LIBROS");
        System.out.print("Ingrese el título: ");
        String busqueda = entrada.nextLine();
        biblioteca.buscarLibro(entrada, "Don quijote de la mancha");
        
        System.out.println("\n");
        System.out.println("3. PRESTAR LIBROS");
        biblioteca.prestarLibro(entrada, "Cien años de soledad");

        System.out.println("\n");
        System.out.println("4. DEVOLVER LIBROS");
        biblioteca.devolverLibro(entrada, "Don quijote de la mancha");

        System.out.println("\n");
        System.out.println("5. MOSTRAR LIBROS");
        biblioteca.mostrarLibrosDisponibles();
    }

}
